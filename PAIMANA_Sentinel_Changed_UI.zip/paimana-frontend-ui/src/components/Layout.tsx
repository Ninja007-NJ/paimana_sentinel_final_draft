import { 
  Menu, 
  X, 
  Info,
  LayoutDashboard,
  Building2,
  TrendingUp,
  Bell,
  Sun,
  Moon,
  Bot
} from "lucide-react";
import { useState, useEffect } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { triggerButtonFeedback } from "../utils/haptics";

export function Layout() {
  const [open, setOpen] = useState(false);
  const [showPitchModal, setShowPitchModal] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    return (localStorage.getItem("paimana_theme") as "dark" | "light") || "dark";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("paimana_theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const handleToggleSentinel = (e: React.MouseEvent<HTMLElement>) => {
    triggerButtonFeedback(e, "pop");
    window.dispatchEvent(new CustomEvent("toggle-sentinel-ai"));
  };

  return (
    <div className="app-shell">
      {/* 1. Left Fixed Sidebar */}
      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="sidebar-top-section">
          {/* Brand */}
          <div className="sidebar-brand">
            <div className="brand-logo">▲</div>
            <div className="brand-text-block">
              <strong className="brand-title">PAIMANA Sentinel</strong>
              <span className="brand-sub">MoSPI Decision Support</span>
            </div>
            <button 
              className="mobile-close" 
              onClick={() => setOpen(false)}
              aria-label="Close navigation"
            >
              <X size={18} />
            </button>
          </div>

          {/* Primary Navigation: Dashboard (renamed from Command Center), Projects, Analytics, Alerts */}
          <nav className="nav-list" aria-label="Primary navigation">
            <NavLink 
              to="/" 
              end 
              onClick={() => setOpen(false)} 
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <LayoutDashboard size={16} /> 
              <span>Dashboard</span>
            </NavLink>
            <NavLink 
              to="/projects" 
              onClick={() => setOpen(false)} 
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <Building2 size={16} /> 
              <span>Projects</span>
            </NavLink>
            <NavLink 
              to="/analytics" 
              onClick={() => setOpen(false)} 
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <TrendingUp size={16} /> 
              <span>Analytics</span>
            </NavLink>
            <NavLink 
              to="/alerts" 
              onClick={() => setOpen(false)} 
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
            >
              <Bell size={16} /> 
              <span>Alerts</span>
            </NavLink>
          </nav>
        </div>

        {/* Bottom Section with Watermark & SIH Project Brief */}
        <div className="sidebar-footer">
          <button 
            className="sih-pitch-btn" 
            onClick={(e) => {
              triggerButtonFeedback(e, "snap");
              setShowPitchModal(true);
            }}
            title="View Problem Statement & Architecture"
          >
            <Info size={13} />
            <span>SIH Project Brief</span>
          </button>

          <div className="watermark-box">
            <div className="tricolor-bar">
              <div className="saffron" />
              <div className="white" />
              <div className="green" />
            </div>
            <div className="mospi-caption">
              Ministry of Statistics &amp; Programme Implementation<br />
              <strong className="text-gov">Government of India</strong>
            </div>
          </div>
        </div>
      </aside>

      {open && (
        <button 
          className="scrim" 
          onClick={() => setOpen(false)} 
          aria-label="Close navigation overlay" 
        />
      )}

      {/* 2. Main Column */}
      <div className="main-column">
        {/* Fixed Topbar */}
        <header className="topbar">
          <div className="topbar-left">
            <button 
              className="menu-button" 
              onClick={() => setOpen(prev => !prev)} 
              aria-label="Toggle navigation"
            >
              <Menu size={18} />
            </button>
            <div className="topbar-search">
              <input type="text" placeholder="Search projects, ministries, states..." aria-label="Search" />
              <span className="kbd-icon">⌘K</span>
            </div>
          </div>

          <div className="topbar-right">
            {/* Sentinel AI Copilot Collapsible trigger on right side of top navbar */}
            <button 
              type="button" 
              className="sentinel-ai-nav-btn"
              onClick={handleToggleSentinel}
              title="Toggle Sentinel AI Copilot"
            >
              <Bot size={15} className="text-cyan-400" />
              <span className="sentinel-btn-text">Sentinel AI</span>
              <span className="sentinel-ai-dot" />
            </button>

            <NavLink to="/alerts" className="notif-btn" title="Recent Alerts" aria-label="Recent Alerts">
              <Bell size={16} />
              <span className="notif-badge">3</span>
            </NavLink>

            <button 
              type="button" 
              className="theme-toggle-btn" 
              title={`Switch to ${theme === "dark" ? "Light" : "Dark"} Theme`}
              onClick={(e) => {
                triggerButtonFeedback(e, "pop");
                toggleTheme();
              }}
              aria-label="Toggle Theme"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </button>

            <div className="user-profile">
              <div className="user-avatar">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80" 
                  alt="Aarav Mehta"
                  className="user-avatar-img"
                />
              </div>
              <div className="user-info">
                <div className="user-name">Aarav Mehta</div>
                <div className="user-role">Central Monitoring Unit <span style={{ fontSize: "9px" }}>▾</span></div>
              </div>
            </div>
          </div>
        </header>

        {/* The ONLY Scrollable Area */}
        <main className="main-scrollable-area">
          <div className="main-wrap">
            <Outlet />
          </div>
        </main>

        {/* Fixed Bottom Navbar / Footer */}
        <footer className="app-footer">
          <div>Ministry of Statistics and Programme Implementation, Government of India</div>
          <div>PAIMANA Sentinel v1.0 • For a Viksit Bharat</div>
          <div className="telemetry-tag">
            <span className="live-dot-pulse" /> Live Telemetry Active
          </div>
        </footer>
      </div>

      {/* SIH Project Brief Modal */}
      {showPitchModal && (
        <div className="modal-overlay" onClick={() => setShowPitchModal(false)}>
          <div className="modal-dossier" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <strong>Smart India Hackathon 2026 — Executive Brief</strong>
                <span>PAIMANA SENTINEL (Team DEADLOCK)</span>
              </div>
              <button 
                onClick={() => setShowPitchModal(false)}
                className="btn-modal-close"
              >
                <X size={16} />
              </button>
            </div>
            
            <div className="modal-body">
              <div>
                <h4 style={{ color: "var(--cyan)", fontSize: "11px", fontWeight: 800, textTransform: "uppercase", marginBottom: "4px" }}>
                  1. Problem Statement
                </h4>
                <p style={{ fontSize: "12px", color: "var(--text-slate)", lineHeight: 1.6 }}>
                  India's ₹55 Lakh Crore central infrastructure pipeline (3,241 projects) experiences major time and cost overruns. Existing OCMS reporting is retrospective after completion targets have already slipped.
                </p>
              </div>

              <div>
                <h4 style={{ color: "var(--cyan)", fontSize: "11px", fontWeight: 800, textTransform: "uppercase", marginBottom: "4px" }}>
                  2. PAIMANA Sentinel Solution
                </h4>
                <p style={{ fontSize: "12px", color: "var(--text-slate)", lineHeight: 1.6 }}>
                  An AI-powered predictive early warning system utilizing ensemble machine learning models to forecast 3-month and 6-month delay probabilities with explainable SHAP risk attributions and automated interventions.
                </p>
              </div>

              <div>
                <h4 style={{ color: "var(--cyan)", fontSize: "11px", fontWeight: 800, textTransform: "uppercase", marginBottom: "4px" }}>
                  3. Technology Stack &amp; Reliability
                </h4>
                <p style={{ fontSize: "12px", color: "var(--text-slate)", lineHeight: 1.6 }}>
                  FastAPI, XGBoost/LightGBM deterministic predictive models, React 19, Recharts, and MoSPI schema validation with strict data reliability auditing.
                </p>
              </div>
            </div>

            <div className="modal-footer">
              <button 
                className="primary-button" 
                onClick={() => setShowPitchModal(false)}
              >
                Close Executive Brief
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
