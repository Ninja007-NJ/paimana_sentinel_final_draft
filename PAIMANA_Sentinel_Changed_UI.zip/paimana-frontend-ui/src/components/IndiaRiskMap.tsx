import { useState, useMemo } from "react";
import India from "@svg-maps/india";
import type { PortfolioRiskRow, ProjectListItem } from "../types";
import { triggerButtonFeedback } from "../utils/haptics";

export interface StateRiskData {
  id: string;
  name: string;
  count: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  avgRisk: number;
  riskBand: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  color: string;
  gradientId: string;
}

const STATE_RISK_REGISTRY: Record<string, StateRiskData> = {
  mh: { id: "mh", name: "Maharashtra (Highest Risk)", count: 206, critical: 61, high: 48, medium: 55, low: 42, avgRisk: 61.4, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  up: { id: "up", name: "Uttar Pradesh", count: 155, critical: 42, high: 36, medium: 45, low: 32, avgRisk: 54.2, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  br: { id: "br", name: "Bihar", count: 110, critical: 38, high: 29, medium: 25, low: 18, avgRisk: 58.7, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  jh: { id: "jh", name: "Jharkhand", count: 80, critical: 16, high: 21, medium: 28, low: 15, avgRisk: 36.4, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  as: { id: "as", name: "Assam & Seven Sisters", count: 112, critical: 20, high: 28, medium: 38, low: 26, avgRisk: 37.4, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  ar: { id: "ar", name: "Arunachal Pradesh", count: 32, critical: 6, high: 10, medium: 10, low: 6, avgRisk: 36.1, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  mn: { id: "mn", name: "Manipur", count: 18, critical: 4, high: 5, medium: 5, low: 4, avgRisk: 35.8, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  ml: { id: "ml", name: "Meghalaya", count: 22, critical: 4, high: 6, medium: 7, low: 5, avgRisk: 34.5, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  mz: { id: "mz", name: "Mizoram", count: 14, critical: 3, high: 4, medium: 4, low: 3, avgRisk: 35.0, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  nl: { id: "nl", name: "Nagaland", count: 16, critical: 3, high: 5, medium: 5, low: 3, avgRisk: 36.5, riskBand: "CRITICAL", color: "#ef4444", gradientId: "heatRed" },
  tr: { id: "tr", name: "Tripura", count: 15, critical: 3, high: 4, medium: 5, low: 3, avgRisk: 33.2, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  sk: { id: "sk", name: "Sikkim", count: 12, critical: 1, high: 3, medium: 4, low: 4, avgRisk: 26.5, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  
  rj: { id: "rj", name: "Rajasthan", count: 62, critical: 11, high: 14, medium: 21, low: 16, avgRisk: 31.5, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  mp: { id: "mp", name: "Madhya Pradesh", count: 101, critical: 18, high: 24, medium: 35, low: 24, avgRisk: 29.8, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  wb: { id: "wb", name: "West Bengal", count: 63, critical: 12, high: 16, medium: 22, low: 13, avgRisk: 32.1, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  or: { id: "or", name: "Odisha", count: 103, critical: 14, high: 22, medium: 38, low: 29, avgRisk: 27.8, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  ct: { id: "ct", name: "Chhattisgarh", count: 76, critical: 11, high: 18, medium: 27, low: 20, avgRisk: 28.5, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  jk: { id: "jk", name: "Jammu & Kashmir / Ladakh", count: 64, critical: 7, high: 14, medium: 22, low: 21, avgRisk: 34.2, riskBand: "MEDIUM", color: "#f59e0b", gradientId: "heatAmber" },
  
  gj: { id: "gj", name: "Gujarat (Most Improved)", count: 126, critical: 6, high: 14, medium: 42, low: 64, avgRisk: 14.1, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ka: { id: "ka", name: "Karnataka", count: 104, critical: 8, high: 18, medium: 36, low: 42, avgRisk: 16.9, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ap: { id: "ap", name: "Andhra Pradesh", count: 115, critical: 9, high: 18, medium: 42, low: 46, avgRisk: 17.6, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  tg: { id: "tg", name: "Telangana", count: 75, critical: 6, high: 12, medium: 28, low: 29, avgRisk: 18.2, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  tn: { id: "tn", name: "Tamil Nadu", count: 50, critical: 4, high: 8, medium: 18, low: 20, avgRisk: 14.2, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  kl: { id: "kl", name: "Kerala", count: 48, critical: 3, high: 7, medium: 18, low: 20, avgRisk: 13.9, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  pb: { id: "pb", name: "Punjab & Chandigarh", count: 46, critical: 2, high: 6, medium: 16, low: 22, avgRisk: 16.2, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  hr: { id: "hr", name: "Haryana", count: 58, critical: 5, high: 11, medium: 22, low: 20, avgRisk: 21.8, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  dl: { id: "dl", name: "Delhi NCR", count: 45, critical: 4, high: 9, medium: 16, low: 16, avgRisk: 19.5, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  hp: { id: "hp", name: "Himachal Pradesh", count: 38, critical: 2, high: 5, medium: 14, low: 17, avgRisk: 17.5, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ut: { id: "ut", name: "Uttarakhand", count: 42, critical: 2, high: 5, medium: 15, low: 20, avgRisk: 16.8, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ga: { id: "ga", name: "Goa", count: 18, critical: 1, high: 2, medium: 6, low: 9, avgRisk: 14.5, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ch: { id: "ch", name: "Chandigarh", count: 12, critical: 1, high: 2, medium: 4, low: 5, avgRisk: 13.8, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  an: { id: "an", name: "Andaman & Nicobar", count: 10, critical: 1, high: 2, medium: 3, low: 4, avgRisk: 15.2, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  ld: { id: "ld", name: "Lakshadweep", count: 4, critical: 0, high: 1, medium: 1, low: 2, avgRisk: 12.0, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  py: { id: "py", name: "Puducherry", count: 8, critical: 1, high: 1, medium: 2, low: 4, avgRisk: 14.0, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  dn: { id: "dn", name: "Dadra & Nagar Haveli", count: 6, critical: 0, high: 1, medium: 2, low: 3, avgRisk: 14.8, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" },
  dd: { id: "dd", name: "Daman & Diu", count: 5, critical: 0, high: 1, medium: 2, low: 2, avgRisk: 14.5, riskBand: "LOW", color: "#10b981", gradientId: "heatGreen" }
};

export function IndiaRiskMap({ 
  projects = [],
  onSelectState 
}: { 
  projects: (ProjectListItem | PortfolioRiskRow)[];
  onSelectState?: (stateName: string) => void;
}) {
  const [activeTab, setActiveTab] = useState<"Risk Level" | "Sector" | "Ministry" | "Progress">("Risk Level");
  const [selectedStateId, setSelectedStateId] = useState<string>("tn");
  const [hoveredStateId, setHoveredStateId] = useState<string>("tn");
  const [zoom, setZoom] = useState<number>(1);

  const currentState = useMemo(() => {
    return STATE_RISK_REGISTRY[hoveredStateId] || STATE_RISK_REGISTRY["tn"];
  }, [hoveredStateId]);

  return (
    <article className="card india-map-card" id="map">
      {/* Header matching Image 3: GEOGRAPHICAL RISK MAP OF INDIA with subtitle & pill filters */}
      <div className="card-head">
        <div>
          <div className="card-title">
            <span className="dot" style={{ background: "var(--cyan)" }} />
            <span>GEOGRAPHICAL RISK MAP OF INDIA</span>
          </div>
          <p className="card-subtitle" style={{ fontSize: "12px", color: "var(--text-muted)", marginTop: "2px" }}>
            Spatial concentration of infrastructure delay risk and regional project density
          </p>
        </div>

        <div className="pill-tabs" role="tablist">
          {(["Risk Level", "Sector", "Ministry", "Progress"] as const).map((tab) => (
            <button
              key={tab}
              className={`tab-btn ${activeTab === tab ? "active" : ""}`}
              onClick={(e) => {
                triggerButtonFeedback(e, "pop");
                setActiveTab(tab);
              }}
              type="button"
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Container */}
      <div className="map-container" style={{ position: "relative", minHeight: "360px", height: "390px", overflow: "hidden" }}>
        
        {/* SVG Detailed Realistic Map of India using official boundary paths */}
        <div 
          className="map-svg-wrap" 
          style={{ 
            transform: `scale(${zoom})`, 
            transformOrigin: "center center", 
            transition: "transform 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <svg 
            className="india-map-svg" 
            viewBox={India.viewBox || "0 0 612 696"} 
            aria-label="Official Geographical Map of India with State Risk Levels"
            style={{ width: "100%", height: "100%", filter: "drop-shadow(0 0 25px rgba(0, 0, 0, 0.95))" }}
          >
            <defs>
              <radialGradient id="heatRed" cx="50%" cy="50%" r="55%">
                <stop offset="0%" stopColor="#ef4444" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#991b1b" stopOpacity="0.9" />
              </radialGradient>
              <radialGradient id="heatAmber" cx="50%" cy="50%" r="55%">
                <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#b45309" stopOpacity="0.9" />
              </radialGradient>
              <radialGradient id="heatGreen" cx="50%" cy="50%" r="55%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#047857" stopOpacity="0.9" />
              </radialGradient>

              {/* Glowing highlight filter for active/highest risk state */}
              <filter id="neonGlow" x="-25%" y="-25%" width="150%" height="150%">
                <feGaussianBlur stdDeviation="3.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Official Surveyed Geographical State Paths */}
            <g id="india-official-states">
              {India.locations.map((loc: { id: string; name: string; path: string }) => {
                const stateData = STATE_RISK_REGISTRY[loc.id] || {
                  id: loc.id,
                  name: loc.name,
                  count: 25,
                  critical: 2,
                  high: 4,
                  medium: 8,
                  low: 11,
                  avgRisk: 18.5,
                  riskBand: "LOW",
                  color: "#10b981",
                  gradientId: "heatGreen"
                };

                const isSelected = selectedStateId === loc.id;
                const isHovered = hoveredStateId === loc.id;

                return (
                  <path
                    key={loc.id}
                    id={`state-${loc.id}`}
                    className="state-path"
                    d={loc.path}
                    fill={`url(#${stateData.gradientId})`}
                    stroke={isSelected ? "#ffffff" : isHovered ? "#ffffff" : "#070d18"}
                    strokeWidth={isSelected ? "2.2" : isHovered ? "1.8" : "0.85"}
                    filter={isSelected || loc.id === "mh" ? "url(#neonGlow)" : undefined}
                    style={{
                      cursor: "pointer",
                      transition: "fill 0.2s, stroke 0.2s, stroke-width 0.2s, opacity 0.2s",
                      opacity: isHovered || isSelected ? 1 : 0.92
                    }}
                    onMouseEnter={() => setHoveredStateId(loc.id)}
                    onClick={() => {
                      setSelectedStateId(loc.id);
                      setHoveredStateId(loc.id);
                      onSelectState?.(stateData.name);
                    }}
                  >
                    <title>{`${stateData.name} - ${stateData.count} Projects (Avg Risk: ${stateData.avgRisk}%)`}</title>
                  </path>
                );
              })}
            </g>

            {/* Pulsing Highlight Beacon over Maharashtra (Centroid: 180, 435) */}
            <g transform="translate(180, 435)">
              <circle cx="0" cy="0" r="16" fill="#ef4444" opacity="0.3">
                <animate attributeName="r" values="8;20;8" dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.45;0.05;0.45" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx="0" cy="0" r="4.5" fill="#ffffff" stroke="#ef4444" strokeWidth="2" />
            </g>
          </svg>
        </div>

        {/* Floating Tooltip Card matching Image 3 (Tamil Nadu card) */}
        {currentState && (
          <div 
            className="map-tooltip" 
            style={{
              position: "absolute",
              top: "12px",
              left: "14px",
              background: "rgba(10, 18, 32, 0.95)",
              backdropFilter: "blur(10px)",
              border: "1px solid #38bdf8",
              borderRadius: "8px",
              padding: "8px 12px",
              boxShadow: "0 8px 24px rgba(0, 0, 0, 0.85), 0 0 12px rgba(56, 189, 248, 0.3)",
              zIndex: 30,
              pointerEvents: "auto",
              minWidth: "210px"
            }}
          >
            <strong style={{ fontSize: "12px", color: "#ffffff", display: "block", letterSpacing: "-0.01em", fontWeight: 800 }}>
              {currentState.name.replace(/\s*\(.*\)/, "")}
            </strong>
            <span style={{ fontSize: "10px", color: "#94a3b8", display: "block", marginTop: "2px", fontWeight: 600 }}>
              {currentState.count} Projects • Avg: <b style={{ color: "#f43f5e" }}>{currentState.avgRisk}%</b>
            </span>
            <div style={{ display: "flex", gap: "6px", margin: "6px 0", fontSize: "9px", fontWeight: 800 }}>
              <span style={{ color: "#ef4444" }}>● {currentState.critical} Crit</span>
              <span style={{ color: "#f97316" }}>● {currentState.high} High</span>
              <span style={{ color: "#f59e0b" }}>● {currentState.medium} Med</span>
              <span style={{ color: "#10b981" }}>● {currentState.low} Low</span>
            </div>
            <button 
              type="button" 
              onClick={() => onSelectState?.(currentState.name)}
              style={{ background: "transparent", border: "none", color: "#38bdf8", fontWeight: 800, fontSize: "9.5px", cursor: "pointer", padding: 0 }}
            >
              View Projects in State →
            </button>
          </div>
        )}

        {/* Zoom Controls */}
        <div className="map-controls">
          <button type="button" className="zoom-btn" onClick={() => setZoom((z) => Math.min(1.4, z + 0.1))} title="Zoom In">+</button>
          <button type="button" className="zoom-btn" onClick={() => setZoom((z) => Math.max(0.9, z - 0.1))} title="Zoom Out">−</button>
        </div>

        {/* Legend matching Image 3 */}
        <div className="map-legend">
          <div className="legend-row"><span className="legend-dot" style={{ background: "#ef4444" }} /><span>Critical (≥35%)</span></div>
          <div className="legend-row"><span className="legend-dot" style={{ background: "#f97316" }} /><span>High (30–35%)</span></div>
          <div className="legend-row"><span className="legend-dot" style={{ background: "#f59e0b" }} /><span>Medium (22–30%)</span></div>
          <div className="legend-row"><span className="legend-dot" style={{ background: "#10b981" }} /><span>Low (&lt;22%)</span></div>
        </div>
      </div>

      {/* 4 Summary Chips matching user reference Image 3 */}
      <div className="map-summary-chips">
        <div className="chip">
          <div className="chip-label">HIGHEST RISK STATE</div>
          <div className="chip-val">Maharashtra</div>
          <div className="chip-sub" style={{ color: "#ef4444" }}>61% avg. risk</div>
        </div>
        <div className="chip">
          <div className="chip-label">MOST IMPROVED</div>
          <div className="chip-val">Gujarat</div>
          <div className="chip-sub" style={{ color: "#10b981" }}>▲ 12% this month</div>
        </div>
        <div className="chip">
          <div className="chip-label">MOST PROJECTS</div>
          <div className="chip-val">Uttar Pradesh</div>
          <div className="chip-sub" style={{ color: "#38bdf8" }}>155 projects</div>
        </div>
        <div className="chip">
          <div className="chip-label">EMERGING RISK</div>
          <div className="chip-val">North East</div>
          <div className="chip-sub" style={{ color: "#f59e0b" }}>▲ 18% increase</div>
        </div>
      </div>
    </article>
  );
}
