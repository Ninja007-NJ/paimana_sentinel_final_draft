/**
 * Tactile Haptic & Audio Click Feedback Utility
 * Provides realistic physical button feel via Web Audio API micro-sounds and ripple shockwaves.
 */

let audioCtx: AudioContext | null = null;
let soundEnabled = true;

function getAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type ClickFeedbackType = "click" | "snap" | "pop" | "tab";

/**
 * Play an ultra-short, satisfying mechanical switch micro-sound (10-20ms).
 * Simulates physical micro-switch tactile click feedback.
 */
export function playTactileClick(type: ClickFeedbackType = "click") {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === "click") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(1400, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.018);

      gain.gain.setValueAtTime(0.045, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.018);
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.02);
    } else if (type === "snap") {
      osc.type = "triangle";
      osc.frequency.setValueAtTime(850, now);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.028);

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.028);
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.03);
    } else if (type === "tab") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(1900, now);
      osc.frequency.exponentialRampToValueAtTime(260, now + 0.022);

      gain.gain.setValueAtTime(0.055, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.022);
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.025);
    } else if (type === "pop") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(540, now);
      osc.frequency.exponentialRampToValueAtTime(920, now + 0.025);

      gain.gain.setValueAtTime(0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.03);
    }
  } catch {
    // Graceful no-op if audio blocked or unsupported
  }
}

/**
 * Creates an electric cyan ripple shockwave on the clicked button.
 */
export function createClickRipple(e: React.MouseEvent<HTMLElement> | MouseEvent) {
  const target = (e.currentTarget || e.target) as HTMLElement;
  if (!target) return;

  const rect = target.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 2;
  const x = e.clientX - rect.left - size / 2;
  const y = e.clientY - rect.top - size / 2;

  const ripple = document.createElement("span");
  ripple.className = "click-ripple-wave";
  ripple.style.width = `${size}px`;
  ripple.style.height = `${size}px`;
  ripple.style.left = `${x}px`;
  ripple.style.top = `${y}px`;

  target.appendChild(ripple);

  setTimeout(() => {
    ripple.remove();
  }, 450);
}

/**
 * Universal tactile button feedback: Plays mechanical sound + triggers visual ripple
 */
export function triggerButtonFeedback(
  e?: React.MouseEvent<HTMLElement>,
  type: ClickFeedbackType = "click"
) {
  playTactileClick(type);
  if (e) {
    createClickRipple(e);
  }
}
