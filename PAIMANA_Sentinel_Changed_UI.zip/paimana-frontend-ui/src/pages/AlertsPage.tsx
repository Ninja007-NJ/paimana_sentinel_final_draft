import { AlertTriangle, ArrowUpRight, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { PageHeader } from "../components/PageHeader";
import { ReliabilityBadge } from "../components/ReliabilityBadge";
import { RiskBadge } from "../components/RiskBadge";
import { EmptyState, ErrorState, LoadingState } from "../components/StatePanel";
import { useAsync } from "../hooks/useAsync";
import { month, percent } from "../utils/format";
import { alertTypeLabel, displayValue } from "../utils/presentation";

export function AlertsPage() {
  const state = useAsync(() => api.getAlerts(), []);
  const [severity, setSeverity] = useState("");
  const [alertType, setAlertType] = useState("");
  if (state.loading) return <LoadingState label="Building the early warning queue…" />;
  if (state.error) return <ErrorState message="Early-warning data could not be loaded." onRetry={state.retry} />;
  const source = state.data || [];
  const alertTypes = [...new Set(source.map(item => item.alert_type))].sort();
  const alerts = source.filter(item => (!severity || item.severity === severity) && (!alertType || item.alert_type === alertType));
  return <div className="page-stack">
    <PageHeader eyebrow="Portfolio triage" title="Early Warning Centre" description="Deterministic monitoring signals layered on the frozen 3-month delay-risk model." />
    <div className="notice"><ShieldAlert size={18} /><span>Alerts prioritize review; they do not change the model prediction or establish causality.</span></div>
    <section className="panel filter-bar" aria-label="Alert filters"><label>Severity<select value={severity} onChange={event => setSeverity(event.target.value)}><option value="">All severities</option><option value="CRITICAL">Critical</option><option value="WARNING">Warning</option><option value="INFO">Info</option></select></label><label>Alert Type<select value={alertType} onChange={event => setAlertType(event.target.value)}><option value="">All alert types</option>{alertTypes.map(type => <option key={type} value={type}>{alertTypeLabel(type)}</option>)}</select></label><button className="secondary-button" onClick={() => { setSeverity(""); setAlertType(""); }}>Clear filters</button></section>
    {!alerts.length ? <EmptyState title={source.length ? "No alerts match these filters" : "No active alerts"} /> : <section className="panel table-panel"><div className="panel-heading"><div><span className="eyebrow">Prioritized queue</span><h2>{alerts.length.toLocaleString("en-IN")} active alerts</h2></div></div>
      <div className="table-scroll"><table><thead><tr><th>Warning Priority</th><th>Project</th><th>Alert</th><th>Current Risk</th><th>Recent Change</th><th>Data Reliability</th><th>Intervention Priority</th><th>Snapshot</th><th /></tr></thead><tbody>{alerts.map((alert, index) => <tr key={alert.alert_id}><td><strong>#{index + 1}</strong><span className={`severity severity-${alert.severity.toLowerCase()}`}>{alert.severity}</span></td><td><strong>{displayValue(alert.project_name)}</strong><small>{alert.canonical_project_id}</small></td><td><span className="alert-type"><AlertTriangle size={15} />{alertTypeLabel(alert.alert_type)}</span><small>{alert.explanation}</small></td><td><RiskBadge level={alert.current_risk >= .75 ? "CRITICAL" : alert.current_risk >= .5 ? "HIGH" : "MEDIUM"} /><small>{percent(alert.current_risk)}</small></td><td>{alert.recent_risk_change == null ? "—" : `${alert.recent_risk_change >= 0 ? "+" : ""}${(alert.recent_risk_change * 100).toFixed(1)} pp`}</td><td><ReliabilityBadge score={alert.data_reliability_score} /></td><td>{alert.intervention_priority_score == null ? "—" : <><strong>{alert.intervention_priority_score.toFixed(1)} / 100</strong><small>Review ranking</small></>}</td><td>{month(alert.latest_snapshot_month)}</td><td><Link className="icon-link" to={`/projects/${encodeURIComponent(alert.canonical_project_id)}`} aria-label={`Open ${displayValue(alert.project_name)}`}><ArrowUpRight size={17} /></Link></td></tr>)}</tbody></table></div>
    </section>}
  </div>;
}
