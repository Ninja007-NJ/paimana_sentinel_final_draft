import { ArrowDown, ArrowRight, ArrowUp, Gauge, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { PageHeader } from "../components/PageHeader";
import { ReliabilityBadge } from "../components/ReliabilityBadge";
import { EmptyState, ErrorState, LoadingState } from "../components/StatePanel";
import { useAsync } from "../hooks/useAsync";
import type { PriorityRecord } from "../types";
import { percent } from "../utils/format";
import { displayValue } from "../utils/presentation";

const PAGE_SIZE = 25;

export function InterventionPriorityPage() {
  const state = useAsync(() => api.getPriorities(), []);
  const [level, setLevel] = useState("");
  const [trajectory, setTrajectory] = useState("");
  const [action, setAction] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const filtered = useMemo(() => (state.data || []).filter(item =>
    (!level || item.intervention_priority_level === level) &&
    (!trajectory || item.trajectory_status === trajectory) &&
    (!action || item.recommended_review_action === action) &&
    (!search || `${item.project_name} ${item.canonical_project_id}`.toLocaleLowerCase("en-IN").includes(search.toLocaleLowerCase("en-IN")))
  ), [state.data, level, trajectory, action, search]);
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const rows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  function update(setter: (value: string) => void, value: string) { setter(value); setPage(1); }

  if (state.loading) return <LoadingState label="Building the national intervention queue…" />;
  if (state.error) return <ErrorState message="Intervention priorities could not be loaded." onRetry={state.retry} />;
  return <div className="page-stack">
    <PageHeader eyebrow="Deterministic review ranking" title="Intervention Priority" description="Ranks projects for official review using existing model risks, trajectory, alerts, peers, exposure, and schedule pressure. The score is not a probability." />
    <section className="priority-summary-grid"><Summary label="Eligible projects" value={(state.data || []).length} /><Summary label="Critical priority" value={(state.data || []).filter(item => item.intervention_priority_level === "CRITICAL").length} /><Summary label="Immediate review" value={(state.data || []).filter(item => item.recommended_review_action === "IMMEDIATE_REVIEW").length} /><Summary label="Insufficient history" value={(state.data || []).filter(item => item.trajectory_status === "INSUFFICIENT_HISTORY").length} /></section>
    <section className="panel priority-filter-panel"><label className="priority-search"><span>Project</span><div><Search size={15} /><input aria-label="Search priority projects" value={search} placeholder="Search name or ID" onChange={event => update(setSearch, event.target.value)} /></div></label><Filter label="Priority level" value={level} options={["CRITICAL", "HIGH", "MEDIUM", "LOW"]} onChange={value => update(setLevel, value)} /><Filter label="Risk trend" value={trajectory} options={["ACCELERATING", "RAPIDLY_RISING", "RISING", "STABLE", "IMPROVING", "INSUFFICIENT_HISTORY"]} onChange={value => update(setTrajectory, value)} /><Filter label="Recommended action" value={action} options={["IMMEDIATE_REVIEW", "EARLY_INTERVENTION", "VERIFY_DATA_URGENTLY", "ROUTINE_MONITORING"]} onChange={value => update(setAction, value)} /></section>
    <section className="panel table-panel"><div className="panel-heading"><div><span className="eyebrow">National queue</span><h2><Gauge size={19} /> Projects officials should review first</h2></div><span className="quiet-note">{filtered.length.toLocaleString("en-IN")} matching projects · deterministic descending score</span></div>{!rows.length ? <EmptyState title="No projects match these filters" /> : <div className="table-scroll"><table className="intervention-table"><thead><tr><th>Rank</th><th>Project</th><th>3-Month Risk</th><th>6-Month Risk</th><th>Trend</th><th>Data Reliability</th><th>Priority Score</th><th>Priority Level</th><th>Recommended Action</th></tr></thead><tbody>{rows.map(item => <PriorityRow key={item.canonical_project_id} item={item} />)}</tbody></table></div>}<div className="pagination"><span>Page {page} of {pageCount}</span><div><button disabled={page === 1} onClick={() => setPage(page - 1)}>Previous</button><button disabled={page === pageCount} onClick={() => setPage(page + 1)}>Next</button></div></div></section>
  </div>;
}

function PriorityRow({ item }: { item: PriorityRecord }) {
  return <tr><td><strong>#{item.rank}</strong></td><td><Link className="project-link" to={`/projects/${encodeURIComponent(item.canonical_project_id)}`}><strong>{displayValue(item.project_name)}</strong><span>{item.canonical_project_id}</span></Link><small>{displayValue(item.sector, "sector")} · {displayValue(item.state, "state")}</small><small>{item.key_reason}</small></td><td>{percent(item.delay_probability_3m)}</td><td>{percent(item.delay_probability_6m)}</td><td><Trend status={item.trajectory_status} /><small>{item.risk_change_1m == null ? "No last-period value" : `${item.risk_change_1m >= 0 ? "+" : ""}${(item.risk_change_1m * 100).toFixed(1)} pp`}</small></td><td><ReliabilityBadge score={item.data_reliability_score} /></td><td><strong>{item.intervention_priority_score.toFixed(1)} / 100</strong><small>Not a probability</small></td><td><span className={`priority-level priority-${item.intervention_priority_level.toLowerCase()}`}>{displayLabel(item.intervention_priority_level)}</span></td><td><strong>{displayLabel(item.recommended_review_action)}</strong></td></tr>;
}

export function Trend({ status }: { status: PriorityRecord["trajectory_status"] }) {
  const improving = status === "IMPROVING";
  const stable = status === "STABLE" || status === "INSUFFICIENT_HISTORY";
  const Icon = improving ? ArrowDown : stable ? ArrowRight : ArrowUp;
  return <span className={`trajectory-label trajectory-${status.toLowerCase().replaceAll("_", "-")}`}><Icon size={14} /> {displayLabel(status)}</span>;
}

function displayLabel(value: string) { return value.replaceAll("_", " ").toLocaleLowerCase("en-IN").replace(/\b\w/g, letter => letter.toLocaleUpperCase("en-IN")); }
function Summary({ label, value }: { label: string; value: number }) { return <article><span>{label}</span><strong>{value.toLocaleString("en-IN")}</strong></article>; }
function Filter({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) { return <label><span>{label}</span><select value={value} onChange={event => onChange(event.target.value)}><option value="">All</option>{options.map(option => <option value={option} key={option}>{displayLabel(option)}</option>)}</select></label>; }
