import { BarChart3, Landmark, MapPinned, Shapes } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api/client";
import { AssistantPanel } from "../components/AssistantPanel";
import { PageHeader } from "../components/PageHeader";
import { StatCard } from "../components/StatCard";
import { ErrorState, LoadingState } from "../components/StatePanel";
import { useAsync } from "../hooks/useAsync";
import type { GroupAnalytics } from "../types";
import { crore, percent } from "../utils/format";
import { displayValue } from "../utils/presentation";

export function PortfolioAnalyticsPage() {
  const portfolioState = useAsync(() => api.getPortfolioAnalytics(), []);
  const sectorsState = useAsync(() => api.getSectorAnalytics(), []);
  const ministriesState = useAsync(() => api.getMinistryAnalytics(), []);
  const statesState = useAsync(() => api.getStateAnalytics(), []);
  if (portfolioState.loading) return <LoadingState label="Aggregating portfolio intelligence…" />;
  if (portfolioState.error) return <ErrorState message="Portfolio analytics could not be loaded." onRetry={portfolioState.retry} />;
  const portfolio = portfolioState.data!;
  const ministries = ministriesState.data || [];
  return <div className="page-stack">
    <PageHeader eyebrow="MoSPI portfolio view" title="Portfolio Analytics" description={`Comparisons include groups with at least ${portfolio.minimum_group_size} projects to avoid misleading small-sample rankings.`} />
    <section className="stat-grid"><StatCard label="Monitored projects" value={portfolio.summary.project_count.toLocaleString("en-IN")} helper="Latest project snapshots" icon={BarChart3} /><StatCard label="Average delay risk" value={percent(portfolio.summary.average_delay_risk)} helper={`Median ${percent(portfolio.summary.median_delay_risk)}`} icon={Shapes} /><StatCard label="High / critical" value={portfolio.summary.high_risk_count.toLocaleString("en-IN")} helper={`${portfolio.summary.high_risk_percentage.toFixed(1)}% of portfolio · ${portfolio.summary.active_alert_count} alerts`} icon={Landmark} /><StatCard label="Current portfolio cost" value={crore(portfolio.summary.aggregate_current_cost_cr)} helper={`Expenditure ${crore(portfolio.summary.aggregate_expenditure_cr)}`} icon={MapPinned} /></section>
    <AssistantPanel />
    <section className="dashboard-grid"><article className="panel chart-panel"><div className="panel-heading"><h2>Portfolio risk distribution</h2></div><ResponsiveContainer width="100%" height={280}><BarChart data={portfolio.risk_distribution}><CartesianGrid stroke="#e7edf1" /><XAxis dataKey="risk_level" /><YAxis /><Tooltip /><Bar dataKey="count" fill="#176b87" radius={[4,4,0,0]} /></BarChart></ResponsiveContainer></article>
      <article className="panel chart-panel"><div className="panel-heading"><h2>Portfolio risk trend</h2></div><ResponsiveContainer width="100%" height={280}><LineChart data={portfolio.risk_trend.map(row => ({...row, riskPct: row.average_delay_risk * 100}))}><CartesianGrid stroke="#e7edf1" /><XAxis dataKey="snapshot_month" /><YAxis yAxisId="risk" unit="%" /><YAxis yAxisId="count" orientation="right" /><Tooltip /><Legend /><Line yAxisId="risk" dataKey="riskPct" name="Average risk" stroke="#b83b3b" strokeWidth={2.4} /><Line yAxisId="count" dataKey="high_or_critical_count" name="High / critical projects" stroke="#176b87" strokeWidth={2} /></LineChart></ResponsiveContainer></article></section>
    <GroupResult title="Sector risk comparison" state={sectorsState} keyName="sector" />
    <GroupResult title="Ministry / Department comparison" state={ministriesState} keyName="ministry_department" />
    <GroupResult title="State comparison" state={statesState} keyName="state" />
    {!ministriesState.loading && !ministriesState.error && <section className="dashboard-grid"><GroupTable title="Fastest-worsening ministries" rows={[...ministries].filter(row => row.risk_change_1m != null).sort((a,b) => (b.risk_change_1m || 0) - (a.risk_change_1m || 0)).slice(0, 10)} keyName="ministry_department" /><GroupTable title="Lowest reporting reliability" rows={[...ministries].sort((a,b) => a.average_data_reliability - b.average_data_reliability).slice(0, 10)} keyName="ministry_department" /></section>}
  </div>;
}

function GroupResult({ title, state, keyName }: { title: string; state: { data: GroupAnalytics[] | null; error: Error | null; loading: boolean; retry: () => void }; keyName: "sector" | "ministry_department" | "state" }) {
  if (state.loading) return <section className="panel"><LoadingState label={`Loading ${title.toLowerCase()}…`} /></section>;
  if (state.error) return <section className="panel"><ErrorState message={`${title} could not be loaded.`} onRetry={state.retry} /></section>;
  return <GroupTable title={title} rows={state.data || []} keyName={keyName} />;
}

function GroupTable({ title, rows, keyName }: { title: string; rows: GroupAnalytics[]; keyName: "sector" | "ministry_department" | "state" }) {
  const kind = keyName === "ministry_department" ? "ministry" : keyName;
  return <section className="panel table-panel"><div className="panel-heading"><h2>{title}</h2><span className="quiet-note">Sample sizes shown; groups below the minimum are suppressed</span></div>{!rows.length ? <div className="state-panel"><strong>No reportable groups</strong><span>No groups met the minimum sample size.</span></div> : <div className="table-scroll"><table><thead><tr><th>Group</th><th>Projects</th><th>Average / Median Risk</th><th>High / Critical</th><th>Rapidly Rising</th><th>Data Reliability</th><th>Current Cost</th></tr></thead><tbody>{rows.slice(0, 30).map(row => <tr key={String(row[keyName] || "Unknown")}><td><strong>{displayValue(row[keyName], kind)}</strong></td><td>{row.project_count ?? 0}</td><td>{percent(row.average_delay_risk)} / {percent(row.median_delay_risk)}</td><td>{row.high_risk_count ?? 0} ({Number.isFinite(row.high_risk_percentage) ? row.high_risk_percentage.toFixed(1) : "0.0"}%)</td><td>{row.rapidly_rising_risk_count ?? 0}</td><td>{Number.isFinite(row.average_data_reliability) ? row.average_data_reliability.toFixed(1) : "—"} / 100</td><td>{crore(row.aggregate_current_cost_cr)}</td></tr>)}</tbody></table></div>}</section>;
}
