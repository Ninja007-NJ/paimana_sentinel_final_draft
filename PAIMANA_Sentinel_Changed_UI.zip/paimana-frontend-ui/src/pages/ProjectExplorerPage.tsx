import { ChevronLeft, ChevronRight, Filter, Search, TrendingDown, TrendingUp } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import { PageHeader } from "../components/PageHeader";
import { ReliabilityBadge } from "../components/ReliabilityBadge";
import { RiskBadge } from "../components/RiskBadge";
import { EmptyState, ErrorState, LoadingState } from "../components/StatePanel";
import { useAsync } from "../hooks/useAsync";
import type { PortfolioRiskRow, ProjectDetail, ProjectListItem } from "../types";
import { month, percent } from "../utils/format";
import { displayValue } from "../utils/presentation";
import { reliabilityLevel } from "../utils/reliability";

const PAGE_SIZE = 15;

export function ProjectExplorerPage() {
  const projectsState = useAsync(() => api.getProjects(), []);
  const [portfolioRows, setPortfolioRows] = useState<PortfolioRiskRow[]>([]);
  const [details, setDetails] = useState<Record<string, ProjectDetail>>({});
  const [filters, setFilters] = useState({ name: "", sector: "", state: "", ministry: "", risk: "", reliability: "" });
  const [page, setPage] = useState(1);

  useEffect(() => {
    if (!projectsState.data) return;
    api.hydratePortfolioRisk(projectsState.data, (_done, _total, rows) => setPortfolioRows(rows)).then(setPortfolioRows).catch(() => undefined);
  }, [projectsState.data]);

  const riskMap = useMemo(() => new Map(portfolioRows.map((row) => [row.canonical_project_id, row])), [portfolioRows]);
  const sectors = useMemo(() => unique(projectsState.data?.map((row) => row.sector) ?? []), [projectsState.data]);
  const states = useMemo(() => unique(projectsState.data?.map((row) => row.state) ?? []), [projectsState.data]);
  const ministries = useMemo(() => unique(Object.values(details).map((row) => row.project_metadata.ministry_department ?? null)), [details]);

  const filtered = useMemo(() => (projectsState.data ?? []).filter((row) => {
    const detail = details[row.canonical_project_id];
    const risk = riskMap.get(row.canonical_project_id)?.risk_level;
    return (!filters.name || `${row.project_name} ${row.canonical_project_id}`.toLowerCase().includes(filters.name.toLowerCase()))
      && (!filters.sector || row.sector === filters.sector)
      && (!filters.state || row.state === filters.state)
      && (!filters.risk || risk === filters.risk)
      && (!filters.reliability || reliabilityLevel(riskMap.get(row.canonical_project_id)?.latest_quality_score) === filters.reliability)
      && (!filters.ministry || detail?.project_metadata.ministry_department === filters.ministry);
  }), [projectsState.data, details, riskMap, filters]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const visible = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    let active = true;
    Promise.all(visible.filter((row) => !details[row.canonical_project_id]).map(async (row) => [row.canonical_project_id, await api.getProject(row.canonical_project_id)] as const))
      .then((entries) => active && entries.length && setDetails((current) => ({ ...current, ...Object.fromEntries(entries) })))
      .catch(() => undefined);
    return () => { active = false; };
  }, [visible.map((row) => row.canonical_project_id).join("|")]);

  useEffect(() => { setPage(1); }, [filters]);

  if (projectsState.loading) return <LoadingState label="Loading Project Explorer…" />;
  if (projectsState.error) return <ErrorState message={projectsState.error.message} onRetry={projectsState.retry} />;

  return <div className="page-stack">
    <PageHeader eyebrow="Project registry" title="Project Explorer" description="Search the frozen portfolio, inspect current risk, and open a full project monitoring record." />
    <section className="filter-panel panel">
      <div className="filter-title"><Filter size={18} /><strong>Filters</strong><span>{filtered.length.toLocaleString("en-IN")} projects</span></div>
      <div className="filter-grid">
        <label className="search-field"><span>Project name or ID</span><div><Search size={16} /><input value={filters.name} onChange={(event) => setFilters({ ...filters, name: event.target.value })} placeholder="Search projects" /></div></label>
        <FilterSelect label="Sector" value={filters.sector} options={sectors} displayKind="sector" onChange={(sector) => setFilters({ ...filters, sector })} />
        <FilterSelect label="State" value={filters.state} options={states} displayKind="state" onChange={(state) => setFilters({ ...filters, state })} />
        <FilterSelect label="Ministry / Department" value={filters.ministry} options={ministries} displayKind="ministry" onChange={(ministry) => setFilters({ ...filters, ministry })} placeholder="Loaded ministries / departments" />
        <FilterSelect label="Risk level" value={filters.risk} options={["LOW", "MEDIUM", "HIGH", "CRITICAL"]} onChange={(risk) => setFilters({ ...filters, risk })} />
        <FilterSelect label="Data reliability" value={filters.reliability} options={["HIGH", "MEDIUM", "LOW"]} onChange={(reliability) => setFilters({ ...filters, reliability })} />
      </div>
      <p className="filter-note">Ministry values are populated from project details as rows load. Risk bands come from backend trajectory responses.</p>
    </section>

    <section className="panel table-panel">
      {!visible.length ? <EmptyState title="No projects match these filters">Clear one or more filters and try again.</EmptyState> : <div className="table-scroll"><table className="project-table"><thead><tr><th>Project</th><th>Sector / State</th><th>Physical Progress</th><th>Current Target</th><th>3-Month Delay Risk</th><th>Risk Level</th><th>Data Reliability</th><th>Risk Trend</th></tr></thead><tbody>{visible.map((row) => <ExplorerRow key={row.canonical_project_id} project={row} detail={details[row.canonical_project_id]} risk={riskMap.get(row.canonical_project_id)} />)}</tbody></table></div>}
      <div className="pagination"><span>Page {page} of {pageCount}</span><div><button disabled={page === 1} onClick={() => setPage((value) => value - 1)} aria-label="Previous page"><ChevronLeft /></button><button disabled={page === pageCount} onClick={() => setPage((value) => value + 1)} aria-label="Next page"><ChevronRight /></button></div></div>
    </section>
  </div>;
}

function ExplorerRow({ project, detail, risk }: { project: ProjectListItem; detail?: ProjectDetail; risk?: PortfolioRiskRow }) {
  return <tr><td><Link to={`/projects/${encodeURIComponent(project.canonical_project_id)}`} className="project-link"><strong>{displayValue(project.project_name)}</strong><span>{project.canonical_project_id}</span></Link></td><td><strong>{displayValue(project.sector, "sector")}</strong><span>{displayValue(project.state, "state")}</span></td><td>{detail ? `${detail.latest_snapshot.physical_progress_pct?.toFixed(1) ?? "-"}%` : <span className="skeleton-cell" />}</td><td>{detail ? month(detail.latest_snapshot.current_target_doc?.slice(0, 7)) : <span className="skeleton-cell" />}</td><td><strong>{percent(project.latest_risk_score)}</strong></td><td>{risk ? <RiskBadge level={risk.risk_level} /> : <span className="quiet-note">Assessing…</span>}</td><td><ReliabilityBadge score={detail?.data_quality_score ?? risk?.latest_quality_score} /></td><td>{risk?.risk_change == null ? <span className="quiet-note">-</span> : risk.risk_change >= 0 ? <span className="trend-up"><TrendingUp size={16} /> +{(risk.risk_change * 100).toFixed(1)} pp</span> : <span className="trend-down"><TrendingDown size={16} /> {(risk.risk_change * 100).toFixed(1)} pp</span>}</td></tr>;
}

function FilterSelect({ label, value, options, onChange, placeholder = "All", displayKind }: { label: string; value: string; options: string[]; onChange: (value: string) => void; placeholder?: string; displayKind?: "state" | "sector" | "ministry" }) {
  return <label><span>{label}</span><select value={value} onChange={(event) => onChange(event.target.value)}><option value="">{placeholder}</option>{options.map((option) => <option key={option} value={option}>{displayKind ? displayValue(option, displayKind) : option}</option>)}</select></label>;
}

function unique(values: (string | null | undefined)[]) {
  return [...new Set(values.filter((value): value is string => Boolean(value)))].sort((a, b) => a.localeCompare(b));
}
